# Inkwell

A roleplay scratch pad for FINAL FANTASY XIV, built on Dalamud. Write long posts in a
comfortable editor, catch typos before they go out, and send them to chat in correctly-headed,
correctly-sized chunks.

## Credit where it's due: Inkwell is built on Wordsmith

Inkwell is **not an original idea.** Its framework (the scratch pad, the chunk preview above
the text box, chat headers, continuation markers, the OOC toggle, spell check, and the
one-click "copy the next chunk" workflow) comes straight from
**[Wordsmith](https://github.com/MythicPalette/Wordsmith-DalamudPlugin)** by
**[MythicPalette](https://github.com/MythicPalette)**.

A huge shoutout to MythicPalette for all the work he has put into Wordsmith. It has made
in-game roleplay easier for a lot of people, and Inkwell exists only because Wordsmith showed
how good this kind of tool can be. If you like Inkwell, please go star Wordsmith too.

Inkwell's code was written from scratch rather than forked, so any bugs in Inkwell are Inkwell's
own and should be reported here, not to Wordsmith.

**Wordsmith repository:** https://github.com/MythicPalette/Wordsmith-DalamudPlugin

## What Inkwell changes and adds

Quality-of-life changes on top of the Wordsmith-style workflow:

- **Resizable text box.** Drag the bar between the chunk preview and the text box to make the
  editor as large as you like. The size is remembered between sessions.
- **Misspellings highlighted where you type.** Misspelled words are marked directly in the
  text box at the bottom (red text, a squiggly underline and/or a background highlight, your
  choice), not only in the preview, so they're easy to find before you copy.
- **Click-to-fix spelling bar.** Every misspelled word is listed as a button above the preview.
  Click one to pick a suggestion, type a replacement, or add the word to your personal
  dictionary.
- **Send to chat.** A **Send to chat** button sits next to **Copy** at the top right. Each click
  posts exactly one chunk to chat; click again for the next. Text is checked against the game's
  own chat filter and the 500-byte limit first, and nothing is ever sent without a click.
- **Copy and Send stay in sync.** Both buttons share one counter ("Copy 2/3", "Send to chat
  2/3"), so using either one moves both to the next chunk.
- **Safety checks before sending.** Optional "Send anyway?" confirmation when there are spelling
  errors, a short cooldown so a double-click can't send two chunks, and a block on chunks that
  would be run as a game command when no chat channel is selected.
- **Spelling warning on the buttons.** Copy and Send turn red while there are possible spelling
  errors, with a tooltip showing how many.
- **Full color and transparency customization.** Under Settings, then Appearance, you can recolor
  the title bar, window background, border, text, toolbar buttons and fields, preview panel, text
  box, resize bar, scrollbars and status messages, each with its own transparency.
- **Status line.** A short message confirms each copy or send, or explains why a send was
  blocked.

### Wordsmith features Inkwell doesn't have (yet)

To be upfront: Wordsmith still does more in some areas. Inkwell currently has a single scratch
pad, no thesaurus, and no custom chat aliases. If you rely on those, Wordsmith is the better
choice for now.

## Install (for players)

Copy this custom repository URL:

```
https://raw.githubusercontent.com/Wyse2011/Inkwell/main/repo.json
```

1. In game, type `/xlsettings` and open the **Experimental** tab.
2. Under **Custom Plugin Repositories**, paste the URL into the empty box, click the **+**
   button, make sure the checkbox next to it is ticked, then click **Save and Close**.
3. Type `/xlplugins`, search for **Inkwell**, and click **Install**.
4. Type `/inkwell` to open the scratch pad, or `/inkwell config` for settings.

Inkwell is a third-party plugin and is not affiliated with Square Enix, Wordsmith or
MythicPalette.

---

# Building from source (for developers)

## Requirements

- XIVLauncher with Dalamud, and the game launched at least once with Dalamud enabled
  (the SDK finds Dalamud's files from that install).
- The .NET SDK version your Dalamud API level uses. If it's wrong, the build error will name the
  version it wants.
- Visual Studio 2022+, Rider, or VS Code with the C# extension.

## 1. Add a dictionary

Spell check needs a word list at `Inkwell/Dictionary/en_US.txt`, one word per line. Any of these
work:

- `words_alpha.txt` from github.com/dwyl/english-words (public domain, large, includes some
  junk words so it will miss some typos)
- A SCOWL list from wordlist.aspell.net (size 60 or 70 is a good balance)
- A Hunspell `.dic` file (the flags after `/` are ignored)

Rename it to `en_US.txt` and put it in `Inkwell/Dictionary/`. You can also drop a list into the
plugin's config folder (`%AppData%\XIVLauncher\pluginConfigs\Inkwell\`) and it will be used
instead, which survives plugin updates.

## 2. Build

```
cd Inkwell
dotnet build -c Debug
```

The DLL ends up in `Inkwell/bin/x64/Debug/Inkwell.dll` (the exact path is printed by the build).

## 3. Load it in game

1. Type `/xlsettings`, open **Experimental**, add the full path to `Inkwell.dll` under
   **Dev Plugin Locations**, and save.
2. Type `/xlplugins`, go to **Dev Tools > Installed Dev Plugins**, and enable Inkwell.
3. Type `/inkwell` to open the scratch pad, `/inkwell config` for settings.

After rebuilding, disable and re-enable the plugin in `/xlplugins` to reload it.

## 4. Publish a release (makes the custom repository work)

The repository URL above reads `repo.json`, which points Dalamud at a file named `latest.zip`
attached to the newest GitHub release. Until a release exists, the plugin will show up in
`/xlplugins` but fail to install.

1. Make sure `Inkwell/Dictionary/en_US.txt` exists on your machine so it gets packed into the zip.
2. Build in Release mode:
   ```
   cd Inkwell
   dotnet build -c Release
   ```
   The SDK's packager creates `Inkwell/bin/x64/Release/Inkwell/latest.zip` (the build output
   shows the exact path).
3. On GitHub, go to **Releases > Draft a new release**, create a tag such as `v0.1.0`, attach
   `latest.zip` (keep that exact file name), and click **Publish release**.

To ship an update: bump `<Version>` in `Inkwell.csproj` and `AssemblyVersion` in `repo.json`
to the same new number, commit, build in Release, and publish a new release with the new
`latest.zip`. Dalamud compares those version numbers to decide when to offer an update. If you
move to a newer Dalamud SDK, update `DalamudApiLevel` in `repo.json` to match.

## If it doesn't compile

Dalamud switched to new ImGui bindings in API 13, and small signature details can shift between
versions. Everything binding-sensitive is in `SpellTextEditor.OnInputCallback`. If that's where
the error is, hover `ImGui.InputTextMultiline` in your IDE to see which callback type it expects
(a `ref ImGuiInputTextCallbackData` or an `ImGuiInputTextCallbackDataPtr`) and whether
`BufDirty` is a `byte` or a `bool`. The logic doesn't change, just the types.

## How the in-editor highlighting works

ImGui can't color individual words inside a text box, so Inkwell draws over it:

- The text box sits inside a scrolling panel and is sized to fit every line, so the box itself
  never scrolls and line positions are always known. The panel scrolls instead, and follows your
  cursor as you type.
- Word wrap is done by turning spaces into newlines. Chat is single-line, so every newline in
  the box is a wrapped space (Enter is blocked). The text length never changes, so spell-check
  positions map exactly onto what's on screen, and they're turned back into spaces before copying.
- After the text box draws, misspelled words are redrawn on top in your highlight color.

## Ideas for next steps

- Right-click a highlighted word in the editor itself to get suggestions.
- Custom chat aliases (e.g. `/friendo` for a frequent /tell target).
- Multiple scratch pads.
- Typing `/p` or `/em` at the start of the text to switch the header automatically.

## Acknowledgements

- [Wordsmith](https://github.com/MythicPalette/Wordsmith-DalamudPlugin) by MythicPalette, the
  plugin whose design and workflow Inkwell is built on.
- [Dalamud](https://github.com/goatcorp/Dalamud) and the goatcorp team.
- [FFXIVClientStructs](https://github.com/aers/FFXIVClientStructs), used for sending chat.
- [dwyl/english-words](https://github.com/dwyl/english-words) (public domain), the default
  spell-check word list.
